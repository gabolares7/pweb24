INSERT INTO almacena_producto (id_puesto, id_producto, cantidad_disponible) VALUES
                                                                                (1, 1, 20),
                                                                                (2, 2, 15),
                                                                                (3, 3, 30),
                                                                                (4, 4, 10),
                                                                                (5, 5, 25),
                                                                                (6, 6, 40),
                                                                                (7, 7, 50),
                                                                                (8, 8, 35),
                                                                                (9, 9, 45),
                                                                                (10, 10, 55);
