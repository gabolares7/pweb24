INSERT INTO pedidos (id, estado, id_usuario, id_puesto) VALUES
                                                            (1, 'pendiente', 1, 5),
                                                            (2, 'pagado', 3, 6),
                                                            (3, 'anulado', 5, 7),
                                                            (4, 'pendiente', 7, 8),
                                                            (5, 'pagado', 9, 1),
                                                            (6, 'anulado', 2, 2),
                                                            (7, 'pendiente', 4, 3),
                                                            (8, 'pagado', 6, 4),
                                                            (9, 'anulado', 8, 5),
                                                            (10, 'pendiente', 10, 6);
