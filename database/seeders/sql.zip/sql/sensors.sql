INSERT INTO sensors (id, magnitud, ubicacion, id_puesto) VALUES
                                                             (1, '°C', 'planta baja', 1),
                                                             (2, 'dB', 'planta alta', 2),
                                                             (3, '°C', NULL, 3),
                                                             (4, 'dB', 'planta baja', 4),
                                                             (5, '°C', 'planta alta', 5),
                                                             (6, 'dB', NULL, 6),
                                                             (7, '°C', 'planta baja', 7),
                                                             (8, 'dB', 'planta alta', 8),
                                                             (9, '°C', NULL, 9),
                                                             (10, 'dB', 'planta baja', 10);
