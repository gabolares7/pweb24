INSERT INTO puestos (id, nombre, ubicacion, descripcion, sector, id_usuario) VALUES
                                                                                 (1, 'Puesto de Carnes', 'planta baja', 'Carnes frescas y de calidad', 'carniceria', 2),
                                                                                 (2, 'Pescaderia Azul', 'planta baja', 'Pescado fresco todos los dias', 'pescaderia', 4),
                                                                                 (3, 'Panaderia Delicias', 'planta alta', 'Pan artesanal y bolleria', 'panaderia', 6),
                                                                                 (4, 'Cafeteria Aroma', 'planta alta', 'Cafe y snacks', 'cafeteria', 8),
                                                                                 (5, 'Fruteria Natural', 'planta baja', 'Frutas frescas y jugos', 'fruteria', 2),
                                                                                 (6, 'Queseria Gourmet', 'planta baja', 'Variedad de quesos', 'queseria', 4),
                                                                                 (7, 'Floristeria Rosa', 'planta alta', 'Flores frescas y plantas', 'floristeria', 6),
                                                                                 (8, 'Mercado Verde', 'planta baja', 'Productos ecologicos', 'fruteria', 8),
                                                                                 (9, 'La Despensa', 'planta alta', 'Productos variados', 'panaderia', 10),
                                                                                 (10, 'Cafeteria Expreso', 'planta baja', 'Cafe rapido y comidas', 'cafeteria', 1);
