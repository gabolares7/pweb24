INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES
                                                                                   (1, 1, 5, 10.00),
                                                                                   (2, 2, 3, 15.50),
                                                                                   (3, 3, 7, 8.75),
                                                                                   (4, 4, 2, 12.30),
                                                                                   (5, 5, 6, 9.20),
                                                                                   (6, 6, 4, 13.40),
                                                                                   (7, 7, 8, 11.00),
                                                                                   (8, 9, 1, 16.50),
                                                                                   (9, 10, 9, 7.30),
                                                                                   (10, 5, 10, 14.25);
