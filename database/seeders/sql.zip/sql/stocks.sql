INSERT INTO stocks (id_producto, id_proveedor, cantidad) VALUES
                                                             (1, 1, 50),
                                                             (2, 2, 30),
                                                             (3, 3, 100),
                                                             (4, 4, 20),
                                                             (5, 5, 150),
                                                             (6, 6, 40),
                                                             (7, 7, 60),
                                                             (8, 4, 80),
                                                             (9, 3, 70),
                                                             (10, 2, 25);
