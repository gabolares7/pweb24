INSERT INTO usuarios (id, nombre, email, contrasena, rol) VALUES
                                                              (1, 'Juan Perez', 'juan.perez@example.com', 'password123', 'comprador'),
                                                              (2, 'Maria Garcia', 'maria.garcia@example.com', 'password456', 'vendedor'),
                                                              (3, 'Carlos Lopez', 'carlos.lopez@example.com', 'password789', 'comprador'),
                                                              (4, 'Laura Sanchez', 'laura.sanchez@example.com', 'password101', 'vendedor'),
                                                              (5, 'Pedro Torres', 'pedro.torres@example.com', 'password102', 'comprador'),
                                                              (6, 'Ana Jimenez', 'ana.jimenez@example.com', 'password103', 'vendedor'),
                                                              (7, 'Luis Martinez', 'luis.martinez@example.com', 'password104', 'comprador'),
                                                              (8, 'Elena Gonzalez', 'elena.gonzalez@example.com', 'password105', 'vendedor'),
                                                              (9, 'Diego Ramirez', 'diego.ramirez@example.com', 'password106', 'comprador'),
                                                              (10, 'Lucia Morales', 'lucia.morales@example.com', 'password107', 'vendedor');
