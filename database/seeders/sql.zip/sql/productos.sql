INSERT INTO productos (id, nombre, categoria, descripcion) VALUES
                                                               (1, 'Carne de res', 'carniceria', 'Corte de primera calidad'),
                                                               (2, 'Pescado fresco', 'pescaderia', 'Del mar a tu mesa'),
                                                               (3, 'Pan integral', 'panaderia', 'Pan saludable y fresco'),
                                                               (4, 'Cafe espresso', 'cafeteria', 'Cafe fuerte y aromatico'),
                                                               (5, 'Manzanas', 'fruteria', 'Frutas frescas y dulces'),
                                                               (6, 'Queso manchego', 'queseria', 'Queso de alta calidad'),
                                                               (7, 'Rosas rojas', 'floristeria', 'Flores frescas y fragantes'),
                                                               (8, 'Batido de frutas', 'cafeteria', 'Bebida natural y refrescante'),
                                                               (9, 'Croissants', 'panaderia', 'Bolleria de mantequilla'),
                                                               (10, 'Pescado congelado', 'pescaderia', 'Ideal para cocinar');
