INSERT INTO detalle_factura (id_factura, id_producto, cantidad) VALUES
                                                                    (1, 1, 5),
                                                                    (2, 2, 3),
                                                                    (3, 3, 7),
                                                                    (4, 4, 2),
                                                                    (5, 5, 6),
                                                                    (6, 6, 4),
                                                                    (7, 7, 8),
                                                                    (8, 8, 1),
                                                                    (9, 9, 9),
                                                                    (10, 10, 10);
