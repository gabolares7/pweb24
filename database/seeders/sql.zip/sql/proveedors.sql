INSERT INTO proveedors (id, contacto, sector) VALUES
                                                  (1, '1234567890', 'carniceria'),
                                                  (2, '0987654321', 'pescaderia'),
                                                  (3, '1122334455', 'panaderia'),
                                                  (4, '5566778899', 'cafeteria'),
                                                  (5, '6677889900', 'fruteria'),
                                                  (6, '2233445566', 'queseria'),
                                                  (7, '3344556677', 'floristeria'),
                                                  (8, '4455667788', 'pescaderia'),
                                                  (9, '5566778890', 'carniceria'),
                                                  (10, '6677889901', 'fruteria');
